#include <iostream>
#include "Racional.h"

using namespace std;

int main() {
    Racional a(1,2);

    cout << a.getNumerador();

    return 0;
}