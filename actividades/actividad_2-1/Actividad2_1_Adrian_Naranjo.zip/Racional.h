class Racional
{
private:
    int numerador;
    int denominador;
public:
    Racional(int numerador, int denominador);
    int getNumerador();
    int getDenominador();
};

