#include "Racional.h"

Racional::Racional(int numerador, int denominador)
{
    this->numerador = numerador;
    this->denominador = denominador;
}

int Racional::getDenominador()
{
    return denominador;
}

int Racional::getNumerador()
{
    return numerador;
}
